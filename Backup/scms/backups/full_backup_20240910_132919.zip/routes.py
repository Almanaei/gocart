from flask import Blueprint, render_template, send_file, url_for, request, redirect, flash, session, current_app, send_from_directory, jsonify
from . import db
from .models import Booking, User, Post
from .forms import LoginForm, RegistrationForm, BookingForm, PostForm, BackupForm
from datetime import datetime, date, timedelta
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy.exc import SQLAlchemyError
from werkzeug.security import check_password_hash, generate_password_hash
from functools import wraps
from flask import abort
import os
import shutil
from reportlab.lib.pagesizes import landscape, letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from io import BytesIO
from sqlalchemy import func
from werkzeug.utils import secure_filename
import traceback
from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField
from wtforms.validators import DataRequired
from flask import current_app
from sqlalchemy import text
import json

# Create a Blueprint named 'main'
bp = Blueprint('main', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

@bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.admin_dashboard'))
    return redirect(url_for('main.login'))

@bp.route('/view_bookings')
@login_required
def view_bookings():
    try:
        current_app.logger.info(f"Attempting to retrieve bookings for user {current_user.id}")
        bookings_query = Booking.query.filter_by(user_id=current_user.id)
        current_app.logger.info(f"Number of bookings found: {bookings_query.count()}")
        
        bookings = []
        for booking in bookings_query:
            try:
                booking_dict = booking.to_dict()  # Use the to_dict method from the Booking model
                current_app.logger.info(f"Processing booking: {booking_dict}")
                
                # Format the dates to remove time
                if booking_dict['booking_date']:
                    booking_dict['booking_date'] = datetime.fromisoformat(booking_dict['booking_date']).strftime('%Y-%m-%d')
                if booking_dict['training_date']:
                    booking_dict['training_date'] = datetime.fromisoformat(booking_dict['training_date']).strftime('%Y-%m-%d')
                
                bookings.append(booking_dict)
            except Exception as e:
                current_app.logger.error(f"Error processing booking {booking.id}: {str(e)}")
                current_app.logger.error(traceback.format_exc())
                # Skip the problematic booking
                continue
        
        current_app.logger.info(f"Retrieved and processed {len(bookings)} bookings")
        return render_template('view_bookings.html', bookings=bookings)
    except Exception as e:
        current_app.logger.error(f"Error retrieving bookings: {str(e)}")
        current_app.logger.error(traceback.format_exc())
        error_message = "An error occurred while retrieving bookings. Please try again later."
        return render_template('view_bookings.html', bookings=None, error_message=error_message)

@bp.route('/edit_booking/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_booking(id):
    booking = Booking.query.get_or_404(id)
    form = BookingForm(obj=booking)
    if form.validate_on_submit():
        booking.client_name = form.client_name.data
        booking.email = form.email.data
        booking.mobile_number = form.mobile_number.data
        booking.booking_date = form.booking_date.data
        booking.training_date = form.set_training_date()
        booking.address = form.address.data
        booking.status = form.status.data
        booking.organization_name = form.organization_name.data
        if form.attachment_filename.data:
            filename = secure_filename(form.attachment_filename.data.filename)
            form.attachment_filename.data.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
            booking.attachment_filename = filename
        db.session.commit()
        flash('Booking updated successfully', 'success')
        return redirect(url_for('main.view_bookings'))
    return render_template('edit_booking.html', form=form, booking=booking)

@bp.route('/create_booking', methods=['GET', 'POST'])
@login_required
def create_booking():
    form = BookingForm()
    if form.validate_on_submit():
        try:
            new_booking = Booking(
                client_name=form.client_name.data,
                email=form.email.data,
                mobile_number=form.mobile_number.data,
                booking_date=form.booking_date.data,
                training_date=form.set_training_date(),
                address=form.address.data,
                user_id=current_user.id,
                status=form.status.data,
                organization_name=form.organization_name.data
            )
            if form.attachment_filename.data:
                filename = secure_filename(form.attachment_filename.data.filename)
                form.attachment_filename.data.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
                new_booking.attachment_filename = filename
            db.session.add(new_booking)
            db.session.commit()
            flash('Booking created successfully', 'success')
            return redirect(url_for('main.view_bookings'))
        except SQLAlchemyError as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating booking: {str(e)}")
            current_app.logger.error(traceback.format_exc())
            flash('An error occurred while creating the booking', 'error')
    return render_template('create_booking.html', form=form)

@bp.route('/delete_booking/<int:id>', methods=['POST'])
def delete_booking(id):
    booking = Booking.query.get_or_404(id)
    db.session.delete(booking)
    db.session.commit()
    flash('Booking deleted successfully', 'success')
    return redirect(url_for('main.view_bookings'))

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.admin_dashboard'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            return redirect(url_for('main.admin_dashboard'))
        flash('Invalid username or password', 'error')
    return render_template('login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@bp.route('/dashboard')
@login_required
def dashboard():
    # Add your dashboard logic here
    return render_template('dashboard.html')

@bp.route('/admin_dashboard')
@login_required
@admin_required
def admin_dashboard():
    try:
        total_bookings = Booking.query.filter_by(user_id=current_user.id).count()
        pending_bookings = Booking.query.filter_by(user_id=current_user.id, status='pending').count()
        total_users = User.query.count()
        total_posts = Post.query.count()
    except Exception as e:
        current_app.logger.error(f"Error in admin_dashboard: {str(e)}")
        total_bookings = pending_bookings = total_users = total_posts = 0

    return render_template('admin_dashboard.html',
                           total_bookings=total_bookings,
                           pending_bookings=pending_bookings,
                           total_users=total_users,
                           total_posts=total_posts)

@bp.route('/create_post', methods=['GET', 'POST'])
@login_required
def create_post():
    form = PostForm()
    if form.validate_on_submit():
        post = Post(title=form.title.data, content=form.content.data, author=current_user)
        db.session.add(post)
        db.session.commit()
        flash('Your post has been created!', 'success')
        return redirect(url_for('main.view_posts'))
    return render_template('create_post.html', title='New Post', form=form)

@bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.password_hash = generate_password_hash(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered user!')
        return redirect(url_for('main.login'))
    return render_template('register.html', form=form)

@bp.route('/booking_calendar')
@login_required
def booking_calendar():
    bookings = Booking.query.all()
    bookings_data = []
    for booking in bookings:
        # Use the booking_date directly, whether it's a string or a date object
        booking_date = booking.booking_date
        if isinstance(booking_date, date):
            booking_date = booking_date.isoformat()
        elif not isinstance(booking_date, str):
            current_app.logger.warning(f"Unexpected booking_date type for booking {booking.id}: {type(booking_date)}")
            continue

        bookings_data.append({
            'title': booking.client_name,
            'start': booking_date,  # This will be either the ISO format string or the original string
            'url': url_for('main.edit_booking', id=booking.id),
            'backgroundColor': {
                'pending': '#ffc107',
                'approved': '#28a745',
                'cancelled': '#dc3545'
            }.get(booking.status.lower(), '#17a2b8')
        })
    
    # Add dummy data if no bookings found
    if not bookings_data:
        bookings_data = [
            {
                'title': 'Dummy Booking',
                'start': datetime.now().date().isoformat(),
                'url': '#',
                'backgroundColor': '#17a2b8'
            }
        ]
    
    bookings_json = json.dumps(bookings_data)
    current_app.logger.info(f"Bookings JSON: {bookings_json}")
    return render_template('booking_calendar.html', bookings_json=bookings_json)

@bp.route('/generate_certificate/<int:booking_id>')
@login_required
def generate_certificate(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=landscape(letter))
    width, height = landscape(letter)
    
    # Set up the certificate
    c.setFont("Helvetica-Bold", 36)
    c.drawCentredString(width/2, height - 2*inch, "Certificate of Training")
    
    c.setFont("Helvetica", 24)
    c.drawCentredString(width/2, height - 3*inch, f"This is to certify that")
    
    c.setFont("Helvetica-Bold", 30)
    c.drawCentredString(width/2, height - 4*inch, booking.client_name)
    
    c.setFont("Helvetica", 24)
    c.drawCentredString(width/2, height - 5*inch, f"has successfully completed the training on")
    
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(width/2, height - 6*inch, booking.training_date.strftime("%B %d, %Y"))
    
    c.showPage()
    c.save()
    
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f'certificate_{booking.client_name}.pdf', mimetype='application/pdf')

@bp.route('/certificate_history')
@login_required
def certificate_history():
    # Implement certificate history logic here
    return render_template('certificate_history.html')

@bp.route('/view_users')
@login_required
@admin_required
def view_users():
    users = User.query.all()
    return render_template('view_users.html', users=users)

@bp.route('/create_user', methods=['GET', 'POST'])
@login_required
@admin_required
def create_user():
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check if the username already exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose a different username.', 'error')
            return render_template('create_user.html', form=form)
        
        try:
            user = User(username=form.username.data, email=form.email.data, is_admin=form.is_admin.data)
            user.password_hash = generate_password_hash(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('New user created successfully', 'success')
            return redirect(url_for('main.view_users'))
        except SQLAlchemyError as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating user: {str(e)}")
            flash('An error occurred while creating the user', 'error')
    return render_template('create_user.html', form=form)

@bp.route('/view_posts')
@login_required
def view_posts():
    posts = Post.query.all()
    return render_template('view_posts.html', posts=posts)

@bp.route('/system_logs')
@login_required
@admin_required
def system_logs():
    log_entries = []
    log_file_path = os.path.join(current_app.root_path, '..', 'logs', 'app.log')
    
    try:
        with open(log_file_path, 'r') as log_file:
            for line in log_file:
                try:
                    # Split the line into timestamp and message
                    timestamp_str, message = line.split(' - ', 1)
                    # Parse the timestamp, ignoring empty strings
                    if timestamp_str.strip():
                        timestamp = datetime.strptime(timestamp_str.strip(), '%Y-%m-%d %H:%M:%S,%f')
                    else:
                        timestamp = None
                    log_entries.append({'timestamp': timestamp, 'message': message.strip()})
                except ValueError:
                    # If parsing fails, add the line as is
                    log_entries.append({'timestamp': None, 'message': line.strip()})
    except FileNotFoundError:
        flash('Log file not found.', 'error')
    except Exception as e:
        flash(f'Error reading log file: {str(e)}', 'error')

    return render_template('system_logs.html', log_entries=log_entries)

@bp.route('/backup_database')
@login_required
@admin_required
def backup_database():
    with current_app.app_context():
        try:
            # Get the current date and time for the backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"backup_{timestamp}.db"
            
            # Define the source and destination paths
            source_path = current_app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
            backup_dir = os.path.join(current_app.root_path, '..', 'backups')
            
            # Create the backups directory if it doesn't exist
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            
            destination_path = os.path.join(backup_dir, backup_filename)
            
            # Perform the backup
            shutil.copy2(source_path, destination_path)
            
            flash(f'Database backup created successfully: {backup_filename}', 'success')
        except Exception as e:
            current_app.logger.error(f"Database backup failed: {str(e)}")
            current_app.logger.error(traceback.format_exc())
            flash('Database backup failed. Please check the logs.', 'error')
        
        return render_template('backup_status.html')

@bp.route('/edit_user/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(id):
    user = User.query.get_or_404(id)
    form = RegistrationForm(obj=user)
    if form.validate_on_submit():
        user.username = form.username.data
        user.email = form.email.data
        if form.password.data:
            user.password_hash = generate_password_hash(form.password.data)
        db.session.commit()
        flash('User updated successfully', 'success')
        return redirect(url_for('main.view_users'))
    return render_template('edit_user.html', form=form, user=user)

@bp.route('/delete_user/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_user(id):
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    flash('User deleted successfully', 'success')
    return redirect(url_for('main.view_users'))

@bp.route('/view_post/<int:id>')
def view_post(id):
    post = Post.query.get_or_404(id)
    return render_template('view_post.html', post=post)

@bp.route('/edit_post/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_post(id):
    post = Post.query.get_or_404(id)
    if current_user.id != post.author_id and not current_user.is_admin:
        abort(403)
    form = PostForm(obj=post)
    if form.validate_on_submit():
        post.title = form.title.data
        post.content = form.content.data
        db.session.commit()
        flash('Your post has been updated!', 'success')
        return redirect(url_for('main.view_post', id=post.id))
    return render_template('edit_post.html', form=form, post=post)

@bp.route('/delete_post/<int:id>', methods=['POST'])
@login_required
def delete_post(id):
    post = Post.query.get_or_404(id)
    if current_user.id != post.author_id and not current_user.is_admin:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash('Your post has been deleted!', 'success')
    return redirect(url_for('main.view_posts'))

@bp.route('/booking_trends')
@login_required
@admin_required
def booking_trends():
    try:
        # Get data for the last 12 months
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)

        # Monthly booking counts
        monthly_bookings = db.session.query(
            func.strftime('%Y-%m', Booking.booking_date).label('month'),
            func.count().label('count')
        ).filter(Booking.booking_date.between(start_date, end_date)
        ).group_by(func.strftime('%Y-%m', Booking.booking_date)).all()

        monthly_bookings_data = [{'month': row.month, 'count': row.count} for row in monthly_bookings]

        # Add debug logging
        current_app.logger.debug(f"Monthly bookings data: {monthly_bookings_data}")

        # Status distribution
        status_distribution = db.session.query(
            Booking.status,
            func.count().label('count')
        ).filter(Booking.booking_date.between(start_date, end_date)
        ).group_by(Booking.status).all()

        status_distribution_data = [{'status': row.status, 'count': row.count} for row in status_distribution]

        # Add more debug logging
        current_app.logger.debug(f"Status distribution data: {status_distribution_data}")

        # Day of week popularity
        day_of_week_popularity = db.session.query(
            func.strftime('%w', Booking.booking_date).label('day_of_week'),
            func.count().label('count')
        ).filter(Booking.booking_date.between(start_date, end_date)
        ).group_by(func.strftime('%w', Booking.booking_date)).all()

        # Convert day numbers to day names
        days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
        day_of_week_data = [{'day': days[int(day)], 'count': count} for day, count in day_of_week_popularity]

        # Add more debug logging
        current_app.logger.debug(f"Day of week data: {day_of_week_data}")

        return render_template('booking_trends.html',
                               monthly_bookings=monthly_bookings_data,
                               status_distribution=status_distribution_data,
                               day_of_week_popularity=day_of_week_data)
    except Exception as e:
        current_app.logger.error(f"Error in booking_trends: {str(e)}")
        current_app.logger.error(traceback.format_exc())
        return render_template('booking_trends.html',
                               monthly_bookings=[],
                               status_distribution=[],
                               day_of_week_popularity=[])

@bp.route('/statistics')
@login_required
@admin_required
def statistics():
    # Total bookings
    total_bookings = Booking.query.count()

    # Bookings by status
    status_counts = db.session.query(Booking.status, func.count(Booking.id)).group_by(Booking.status).all()
    status_dict = dict(status_counts)

    # Bookings in the last 30 days
    thirty_days_ago = datetime.now() - timedelta(days=30)
    recent_bookings = Booking.query.filter(Booking.booking_date >= thirty_days_ago).count()

    # Most popular day of the week
    popular_day = db.session.query(
        func.strftime('%w', Booking.booking_date).label('day_of_week'),
        func.count().label('count')
    ).group_by('day_of_week').order_by(func.count().desc()).first()

    days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    most_popular_day = days[int(popular_day.day_of_week)] if popular_day else 'N/A'

    # Average bookings per month (last 6 months)
    six_months_ago = datetime.now() - timedelta(days=180)
    monthly_counts = db.session.query(
        func.strftime('%Y-%m', Booking.booking_date).label('month'),
        func.count().label('count')
    ).filter(Booking.booking_date >= six_months_ago
    ).group_by('month').all()

    avg_bookings = sum(count for _, count in monthly_counts) / len(monthly_counts) if monthly_counts else 0

    # Top 5 clients by number of bookings
    top_clients = db.session.query(
        Booking.client_name, func.count(Booking.id).label('booking_count')
    ).group_by(Booking.client_name).order_by(func.count(Booking.id).desc()).limit(5).all()

    return render_template('statistics.html', 
                           total_bookings=total_bookings,
                           status_counts=status_dict,
                           recent_bookings=recent_bookings,
                           most_popular_day=most_popular_day,
                           avg_bookings=round(avg_bookings, 2),
                           top_clients=top_clients)

@bp.route('/add_test_bookings')
def add_test_bookings():
    try:
        # Create some test bookings
        for i in range(5):
            booking = Booking(
                client_name=f"Test Client {i+1}",
                email=f"testclient{i+1}@example.com",
                mobile_number=f"123456789{i}",
                booking_date=datetime.now() + timedelta(days=i),
                training_date=datetime.now() + timedelta(days=i+30),
                address=f"Test Address {i+1}",
                status="pending",
                user_id=1  # Assuming user with id 1 exists
            )
            db.session.add(booking)
        
        db.session.commit()
        flash('Test bookings added successfully', 'success')
    except Exception as e:
        current_app.logger.error(f"Error adding test bookings: {str(e)}")
        db.session.rollback()
        flash('Error adding test bookings', 'error')
    
    return redirect(url_for('main.view_bookings'))

@bp.route('/cleanup_dates')
@login_required
@admin_required
def cleanup_dates():
    try:
        bookings = Booking.query.all()
        cleaned_count = 0
        for booking in bookings:
            for date_field in ['booking_date', 'training_date']:
                date_value = getattr(booking, date_field)
                if not isinstance(date_value, datetime):
                    try:
                        if isinstance(date_value, str):
                            setattr(booking, date_field, datetime.fromisoformat(date_value))
                        else:
                            setattr(booking, date_field, None)
                        cleaned_count += 1
                    except ValueError:
                        setattr(booking, date_field, None)
                        cleaned_count += 1
        db.session.commit()
        flash(f'Cleaned up {cleaned_count} date fields', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error cleaning up dates: {str(e)}")
        flash('Error cleaning up dates', 'error')
    return redirect(url_for('main.view_bookings'))

@bp.route('/raw_bookings')
@login_required
@admin_required
def raw_bookings():
    bookings = Booking.query.all()
    booking_data = []
    for booking in bookings:
        booking_dict = {
            'id': booking.id,
            'client_name': booking.client_name,
            'email': booking.email,
            'mobile_number': booking.mobile_number,
            'booking_date': str(booking.booking_date),
            'training_date': str(booking.training_date),
            'status': booking.status,
            'attachment_filename': booking.attachment_filename
        }
        booking_data.append(booking_dict)
    return render_template('raw_bookings.html', bookings=booking_data)

@bp.route('/manual_backup', methods=['GET', 'POST'])
@login_required
@admin_required
def manual_backup():
    form = BackupForm()
    
    if form.validate_on_submit():
        backup_type = form.backup_type.data
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"manual_{backup_type}_backup_{timestamp}.db"
            source_path = current_app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
            backup_dir = os.path.join(current_app.root_path, '..', 'backups')
            if not os.path.exists(backup_dir):
                os.makedirs(backup_dir)
            destination_path = os.path.join(backup_dir, backup_filename)
            shutil.copy2(source_path, destination_path)
            flash(f'{backup_type.capitalize()} backup created successfully: {backup_filename}', 'success')
            current_app.logger.info(f'Manual {backup_type} backup created: {backup_filename}')
        except Exception as e:
            flash(f'Backup failed: {str(e)}', 'error')
            current_app.logger.error(f"Manual backup failed: {str(e)}")
        return redirect(url_for('main.manual_backup'))
    
    return render_template('manual_backup.html', form=form)

@bp.route('/uploads/<filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)

@bp.route('/add_status_column')
def add_status_column():
    with current_app.app_context():
        try:
            db.engine.execute("ALTER TABLE booking ADD COLUMN status VARCHAR(20)")
            db.engine.execute("UPDATE booking SET status = 'pending' WHERE status IS NULL")
            return "Status column added successfully"
        except Exception as e:
            return f"Error adding status column: {str(e)}"

@bp.route('/check_schema')
def check_schema():
    with current_app.app_context():
        result = db.engine.execute("PRAGMA table_info(booking)")
        columns = [row['name'] for row in result]
        return f"Booking table columns: {', '.join(columns)}"

@bp.route('/recreate_booking_table')
def recreate_booking_table():
    with current_app.app_context():
        try:
            db.engine.execute("DROP TABLE IF EXISTS booking")
            db.create_all()
            return "Booking table recreated successfully"
        except Exception as e:
            return f"Error recreating booking table: {str(e)}"

@bp.route('/remove_migration/<revision_id>')
def remove_migration(revision_id):
    with current_app.app_context():
        try:
            db.engine.execute(f"DELETE FROM alembic_version WHERE version_num = '{revision_id}'")
            return f"Revision {revision_id} removed from alembic_version table"
        except Exception as e:
            return f"Error removing revision: {str(e)}"