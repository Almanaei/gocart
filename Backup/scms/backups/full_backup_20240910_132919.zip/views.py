from flask import render_template, current_app, Blueprint
from flask_login import login_required, current_user
from app.models import Booking
from app import db  # Add this import
from datetime import datetime, date
from sqlalchemy import or_
from flask_wtf.csrf import CSRFProtect

# Create a Blueprint
bp = Blueprint('main', __name__)

# Initialize CSRF protection
csrf = CSRFProtect()

@bp.route('/view_bookings')
@login_required
def view_bookings():
    try:
        bookings_query = Booking.query.filter_by(user_id=current_user.id)
        bookings = []
        for booking in bookings_query:
            try:
                booking_dict = {
                    'id': booking.id,
                    'client_name': booking.client_name,
                    'email': booking.email,
                    'mobile_number': booking.mobile_number,
                    'status': booking.status,
                    'attachment_filename': booking.attachment_filename,
                    'address': booking.address,
                    'organization_name': booking.organization_name
                }
                
                # Handle date fields
                for date_field in ['booking_date', 'training_date']:
                    date_value = getattr(booking, date_field)
                    current_app.logger.debug(f"Booking {booking.id} - {date_field}: {date_value}, type: {type(date_value)}")
                    
                    if isinstance(date_value, date):
                        booking_dict[date_field] = date_value.strftime('%Y-%m-%d')
                    elif isinstance(date_value, str):
                        try:
                            parsed_date = datetime.strptime(date_value, '%Y-%m-%d').date()
                            booking_dict[date_field] = parsed_date.strftime('%Y-%m-%d')
                        except ValueError:
                            try:
                                parsed_date = datetime.fromisoformat(date_value).date()
                                booking_dict[date_field] = parsed_date.strftime('%Y-%m-%d')
                            except ValueError:
                                current_app.logger.warning(f"Invalid date format for booking {booking.id}, {date_field}: {date_value}")
                                booking_dict[date_field] = None
                    elif date_value is None:
                        current_app.logger.warning(f"{date_field} is None for booking {booking.id}")
                        booking_dict[date_field] = None
                    else:
                        current_app.logger.error(f"Unexpected type for {date_field} in booking {booking.id}: {type(date_value)}")
                        booking_dict[date_field] = str(date_value)  # Convert to string instead of None
                
                bookings.append(booking_dict)
            except Exception as e:
                current_app.logger.error(f"Error processing booking {booking.id}: {str(e)}", exc_info=True)
                # Skip the problematic booking
                continue
        
        current_app.logger.info(f"Retrieved {len(bookings)} bookings successfully")
        return render_template('view_bookings.html', bookings=bookings)
    except Exception as e:
        current_app.logger.error(f"Error retrieving bookings: {str(e)}", exc_info=True)
        error_message = "An error occurred while retrieving bookings. Please try again later."
        return render_template('view_bookings.html', bookings=None, error_message=error_message)

# Add this query before the view_bookings function to check for problematic bookings
@current_app.route('/check_problematic_bookings')
@login_required
def check_problematic_bookings():
    problematic_bookings = Booking.query.filter(
        or_(
            Booking.booking_date == None,
            Booking.training_date == None,
            ~Booking.booking_date.is_(None) & ~Booking.booking_date.cast(db.String).like('____-__-__'),
            ~Booking.training_date.is_(None) & ~Booking.training_date.cast(db.String).like('____-__-__')
        )
    ).all()

    for booking in problematic_bookings:
        current_app.logger.warning(f"Problematic booking found: ID={booking.id}, booking_date={booking.booking_date}, training_date={booking.training_date}")
    
    return f"Checked {len(problematic_bookings)} problematic bookings. Check the logs for details."

@current_app.route('/inspect_booking/<int:booking_id>')
@login_required
def inspect_booking(booking_id):
    booking = Booking.query.get(booking_id)
    if not booking:
        return f"Booking {booking_id} not found", 404
    
    inspection_result = {
        'id': booking.id,
        'booking_date': f"{booking.booking_date} (type: {type(booking.booking_date)})",
        'training_date': f"{booking.training_date} (type: {type(booking.training_date)})",
        'client_name': booking.client_name,
        'email': booking.email,
        'status': booking.status
    }
    
    return render_template('inspect_booking.html', booking=inspection_result)

@current_app.route('/cleanup_dates')
@login_required
def cleanup_dates():
    try:
        bookings = Booking.query.all()
        cleaned_count = 0
        for booking in bookings:
            for date_field in ['booking_date', 'training_date']:
                date_value = getattr(booking, date_field)
                if not isinstance(date_value, date):
                    try:
                        if isinstance(date_value, str):
                            parsed_date = datetime.strptime(date_value, '%Y-%m-%d').date()
                            setattr(booking, date_field, parsed_date)
                        else:
                            setattr(booking, date_field, None)
                        cleaned_count += 1
                    except ValueError:
                        current_app.logger.warning(f"Could not parse date for booking {booking.id}, {date_field}: {date_value}")
                        setattr(booking, date_field, None)
                        cleaned_count += 1
        db.session.commit()
        return f"Cleaned up {cleaned_count} date fields"
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error cleaning up dates: {str(e)}", exc_info=True)
        return "Error cleaning up dates", 500

@current_app.route('/inspect_all_bookings')
@login_required
def inspect_all_bookings():
    bookings = Booking.query.all()
    inspection_results = []
    for booking in bookings:
        result = {
            'id': booking.id,
            'booking_date': f"{booking.booking_date} (type: {type(booking.booking_date)})",
            'training_date': f"{booking.training_date} (type: {type(booking.training_date)})",
            'client_name': booking.client_name,
            'email': booking.email,
            'status': booking.status
        }
        inspection_results.append(result)
    
    return render_template('inspect_all_bookings.html', bookings=inspection_results)

def init_app(app):
    csrf.init_app(app)
    app.register_blueprint(bp)